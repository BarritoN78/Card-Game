﻿//Barry Norton
//CPT-185
//Card Game Rules Form
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Barry_Norton_CPT_185_Final_Project
{
    public partial class frm_Rules : Form
    {
        public frm_Rules()
        {
            InitializeComponent();
        }

        private void btn_Close_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
