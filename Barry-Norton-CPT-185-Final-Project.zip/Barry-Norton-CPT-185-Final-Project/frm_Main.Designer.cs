﻿namespace Barry_Norton_CPT_185_Final_Project
{
    partial class frm_Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_Main));
            this.btn_Rules = new System.Windows.Forms.Button();
            this.grp_P1_Matches = new System.Windows.Forms.GroupBox();
            this.grp_P1_Match6 = new System.Windows.Forms.GroupBox();
            this.pic_P1_Match6_3 = new System.Windows.Forms.PictureBox();
            this.pic_P1_Match6_2 = new System.Windows.Forms.PictureBox();
            this.pic_P1_Match6_1 = new System.Windows.Forms.PictureBox();
            this.grp_P1_Match5 = new System.Windows.Forms.GroupBox();
            this.pic_P1_Match5_3 = new System.Windows.Forms.PictureBox();
            this.pic_P1_Match5_2 = new System.Windows.Forms.PictureBox();
            this.pic_P1_Match5_1 = new System.Windows.Forms.PictureBox();
            this.grp_P1_Match4 = new System.Windows.Forms.GroupBox();
            this.pic_P1_Match4_3 = new System.Windows.Forms.PictureBox();
            this.pic_P1_Match4_2 = new System.Windows.Forms.PictureBox();
            this.pic_P1_Match4_1 = new System.Windows.Forms.PictureBox();
            this.grp_P1_Match3 = new System.Windows.Forms.GroupBox();
            this.pic_P1_Match3_3 = new System.Windows.Forms.PictureBox();
            this.pic_P1_Match3_2 = new System.Windows.Forms.PictureBox();
            this.pic_P1_Match3_1 = new System.Windows.Forms.PictureBox();
            this.grp_P1_Match2 = new System.Windows.Forms.GroupBox();
            this.pic_P1_Match2_3 = new System.Windows.Forms.PictureBox();
            this.pic_P1_Match2_2 = new System.Windows.Forms.PictureBox();
            this.pic_P1_Match2_1 = new System.Windows.Forms.PictureBox();
            this.grp_P1_Match1 = new System.Windows.Forms.GroupBox();
            this.pic_P1_Match1_3 = new System.Windows.Forms.PictureBox();
            this.pic_P1_Match1_2 = new System.Windows.Forms.PictureBox();
            this.pic_P1_Match1_1 = new System.Windows.Forms.PictureBox();
            this.grp_Player = new System.Windows.Forms.GroupBox();
            this.chk_Card7 = new System.Windows.Forms.CheckBox();
            this.chk_Card6 = new System.Windows.Forms.CheckBox();
            this.chk_Card5 = new System.Windows.Forms.CheckBox();
            this.chk_Card4 = new System.Windows.Forms.CheckBox();
            this.chk_Card3 = new System.Windows.Forms.CheckBox();
            this.chk_Card2 = new System.Windows.Forms.CheckBox();
            this.chk_Card1 = new System.Windows.Forms.CheckBox();
            this.pic_Card7 = new System.Windows.Forms.PictureBox();
            this.pic_Card6 = new System.Windows.Forms.PictureBox();
            this.pic_Card5 = new System.Windows.Forms.PictureBox();
            this.pic_Card4 = new System.Windows.Forms.PictureBox();
            this.pic_Card3 = new System.Windows.Forms.PictureBox();
            this.pic_Card2 = new System.Windows.Forms.PictureBox();
            this.pic_Card1 = new System.Windows.Forms.PictureBox();
            this.btn_Draw = new System.Windows.Forms.Button();
            this.btn_Discard = new System.Windows.Forms.Button();
            this.btn_Match = new System.Windows.Forms.Button();
            this.btn_Next = new System.Windows.Forms.Button();
            this.btn_ExitMain = new System.Windows.Forms.Button();
            this.btn_Replay = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.grp_P2_Matches = new System.Windows.Forms.GroupBox();
            this.grp_P2_Match6 = new System.Windows.Forms.GroupBox();
            this.pic_P2_Match6_3 = new System.Windows.Forms.PictureBox();
            this.pic_P2_Match6_2 = new System.Windows.Forms.PictureBox();
            this.pic_P2_Match6_1 = new System.Windows.Forms.PictureBox();
            this.grp_P2_Match5 = new System.Windows.Forms.GroupBox();
            this.pic_P2_Match5_3 = new System.Windows.Forms.PictureBox();
            this.pic_P2_Match5_2 = new System.Windows.Forms.PictureBox();
            this.pic_P2_Match5_1 = new System.Windows.Forms.PictureBox();
            this.grp_P2_Match4 = new System.Windows.Forms.GroupBox();
            this.pic_P2_Match4_3 = new System.Windows.Forms.PictureBox();
            this.pic_P2_Match4_2 = new System.Windows.Forms.PictureBox();
            this.pic_P2_Match4_1 = new System.Windows.Forms.PictureBox();
            this.grp_P2_Match3 = new System.Windows.Forms.GroupBox();
            this.pic_P2_Match3_3 = new System.Windows.Forms.PictureBox();
            this.pic_P2_Match3_2 = new System.Windows.Forms.PictureBox();
            this.pic_P2_Match3_1 = new System.Windows.Forms.PictureBox();
            this.grp_P2_Match2 = new System.Windows.Forms.GroupBox();
            this.pic_P2_Match2_3 = new System.Windows.Forms.PictureBox();
            this.pic_P2_Match2_2 = new System.Windows.Forms.PictureBox();
            this.pic_P2_Match2_1 = new System.Windows.Forms.PictureBox();
            this.grp_P2_Match1 = new System.Windows.Forms.GroupBox();
            this.pic_P2_Match1_3 = new System.Windows.Forms.PictureBox();
            this.pic_P2_Match1_2 = new System.Windows.Forms.PictureBox();
            this.pic_P2_Match1_1 = new System.Windows.Forms.PictureBox();
            this.pic_Discard = new System.Windows.Forms.PictureBox();
            this.grp_Discard = new System.Windows.Forms.GroupBox();
            this.btn_Take = new System.Windows.Forms.Button();
            this.grp_P1_Matches.SuspendLayout();
            this.grp_P1_Match6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P1_Match6_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P1_Match6_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P1_Match6_1)).BeginInit();
            this.grp_P1_Match5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P1_Match5_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P1_Match5_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P1_Match5_1)).BeginInit();
            this.grp_P1_Match4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P1_Match4_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P1_Match4_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P1_Match4_1)).BeginInit();
            this.grp_P1_Match3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P1_Match3_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P1_Match3_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P1_Match3_1)).BeginInit();
            this.grp_P1_Match2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P1_Match2_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P1_Match2_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P1_Match2_1)).BeginInit();
            this.grp_P1_Match1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P1_Match1_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P1_Match1_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P1_Match1_1)).BeginInit();
            this.grp_Player.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_Card7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_Card6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_Card5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_Card4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_Card3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_Card2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_Card1)).BeginInit();
            this.grp_P2_Matches.SuspendLayout();
            this.grp_P2_Match6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P2_Match6_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P2_Match6_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P2_Match6_1)).BeginInit();
            this.grp_P2_Match5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P2_Match5_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P2_Match5_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P2_Match5_1)).BeginInit();
            this.grp_P2_Match4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P2_Match4_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P2_Match4_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P2_Match4_1)).BeginInit();
            this.grp_P2_Match3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P2_Match3_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P2_Match3_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P2_Match3_1)).BeginInit();
            this.grp_P2_Match2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P2_Match2_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P2_Match2_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P2_Match2_1)).BeginInit();
            this.grp_P2_Match1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P2_Match1_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P2_Match1_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P2_Match1_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_Discard)).BeginInit();
            this.grp_Discard.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_Rules
            // 
            this.btn_Rules.Location = new System.Drawing.Point(1147, 412);
            this.btn_Rules.Name = "btn_Rules";
            this.btn_Rules.Size = new System.Drawing.Size(75, 23);
            this.btn_Rules.TabIndex = 6;
            this.btn_Rules.Text = "&Rules";
            this.toolTip1.SetToolTip(this.btn_Rules, "The program should follow this, but will it?");
            this.btn_Rules.UseVisualStyleBackColor = true;
            this.btn_Rules.Click += new System.EventHandler(this.btn_Rules_Click);
            // 
            // grp_P1_Matches
            // 
            this.grp_P1_Matches.Controls.Add(this.grp_P1_Match6);
            this.grp_P1_Matches.Controls.Add(this.grp_P1_Match5);
            this.grp_P1_Matches.Controls.Add(this.grp_P1_Match4);
            this.grp_P1_Matches.Controls.Add(this.grp_P1_Match3);
            this.grp_P1_Matches.Controls.Add(this.grp_P1_Match2);
            this.grp_P1_Matches.Controls.Add(this.grp_P1_Match1);
            this.grp_P1_Matches.Location = new System.Drawing.Point(12, 12);
            this.grp_P1_Matches.Name = "grp_P1_Matches";
            this.grp_P1_Matches.Size = new System.Drawing.Size(602, 383);
            this.grp_P1_Matches.TabIndex = 1;
            this.grp_P1_Matches.TabStop = false;
            this.grp_P1_Matches.Text = "Player 1\'s Matches";
            // 
            // grp_P1_Match6
            // 
            this.grp_P1_Match6.Controls.Add(this.pic_P1_Match6_3);
            this.grp_P1_Match6.Controls.Add(this.pic_P1_Match6_2);
            this.grp_P1_Match6.Controls.Add(this.pic_P1_Match6_1);
            this.grp_P1_Match6.Location = new System.Drawing.Point(306, 261);
            this.grp_P1_Match6.Name = "grp_P1_Match6";
            this.grp_P1_Match6.Size = new System.Drawing.Size(288, 114);
            this.grp_P1_Match6.TabIndex = 8;
            this.grp_P1_Match6.TabStop = false;
            this.grp_P1_Match6.Text = "Match #6";
            this.grp_P1_Match6.Visible = false;
            // 
            // pic_P1_Match6_3
            // 
            this.pic_P1_Match6_3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pic_P1_Match6_3.Image = ((System.Drawing.Image)(resources.GetObject("pic_P1_Match6_3.Image")));
            this.pic_P1_Match6_3.Location = new System.Drawing.Point(195, 18);
            this.pic_P1_Match6_3.Name = "pic_P1_Match6_3";
            this.pic_P1_Match6_3.Size = new System.Drawing.Size(87, 87);
            this.pic_P1_Match6_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_P1_Match6_3.TabIndex = 3;
            this.pic_P1_Match6_3.TabStop = false;
            // 
            // pic_P1_Match6_2
            // 
            this.pic_P1_Match6_2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pic_P1_Match6_2.Image = ((System.Drawing.Image)(resources.GetObject("pic_P1_Match6_2.Image")));
            this.pic_P1_Match6_2.Location = new System.Drawing.Point(102, 18);
            this.pic_P1_Match6_2.Name = "pic_P1_Match6_2";
            this.pic_P1_Match6_2.Size = new System.Drawing.Size(87, 87);
            this.pic_P1_Match6_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_P1_Match6_2.TabIndex = 2;
            this.pic_P1_Match6_2.TabStop = false;
            // 
            // pic_P1_Match6_1
            // 
            this.pic_P1_Match6_1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pic_P1_Match6_1.Image = ((System.Drawing.Image)(resources.GetObject("pic_P1_Match6_1.Image")));
            this.pic_P1_Match6_1.Location = new System.Drawing.Point(9, 18);
            this.pic_P1_Match6_1.Name = "pic_P1_Match6_1";
            this.pic_P1_Match6_1.Size = new System.Drawing.Size(87, 87);
            this.pic_P1_Match6_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_P1_Match6_1.TabIndex = 1;
            this.pic_P1_Match6_1.TabStop = false;
            // 
            // grp_P1_Match5
            // 
            this.grp_P1_Match5.Controls.Add(this.pic_P1_Match5_3);
            this.grp_P1_Match5.Controls.Add(this.pic_P1_Match5_2);
            this.grp_P1_Match5.Controls.Add(this.pic_P1_Match5_1);
            this.grp_P1_Match5.Location = new System.Drawing.Point(6, 261);
            this.grp_P1_Match5.Name = "grp_P1_Match5";
            this.grp_P1_Match5.Size = new System.Drawing.Size(288, 114);
            this.grp_P1_Match5.TabIndex = 8;
            this.grp_P1_Match5.TabStop = false;
            this.grp_P1_Match5.Text = "Match #5";
            this.grp_P1_Match5.Visible = false;
            // 
            // pic_P1_Match5_3
            // 
            this.pic_P1_Match5_3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pic_P1_Match5_3.Image = ((System.Drawing.Image)(resources.GetObject("pic_P1_Match5_3.Image")));
            this.pic_P1_Match5_3.Location = new System.Drawing.Point(195, 18);
            this.pic_P1_Match5_3.Name = "pic_P1_Match5_3";
            this.pic_P1_Match5_3.Size = new System.Drawing.Size(87, 87);
            this.pic_P1_Match5_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_P1_Match5_3.TabIndex = 3;
            this.pic_P1_Match5_3.TabStop = false;
            // 
            // pic_P1_Match5_2
            // 
            this.pic_P1_Match5_2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pic_P1_Match5_2.Image = ((System.Drawing.Image)(resources.GetObject("pic_P1_Match5_2.Image")));
            this.pic_P1_Match5_2.Location = new System.Drawing.Point(102, 18);
            this.pic_P1_Match5_2.Name = "pic_P1_Match5_2";
            this.pic_P1_Match5_2.Size = new System.Drawing.Size(87, 87);
            this.pic_P1_Match5_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_P1_Match5_2.TabIndex = 2;
            this.pic_P1_Match5_2.TabStop = false;
            // 
            // pic_P1_Match5_1
            // 
            this.pic_P1_Match5_1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pic_P1_Match5_1.Image = ((System.Drawing.Image)(resources.GetObject("pic_P1_Match5_1.Image")));
            this.pic_P1_Match5_1.Location = new System.Drawing.Point(9, 18);
            this.pic_P1_Match5_1.Name = "pic_P1_Match5_1";
            this.pic_P1_Match5_1.Size = new System.Drawing.Size(87, 87);
            this.pic_P1_Match5_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_P1_Match5_1.TabIndex = 1;
            this.pic_P1_Match5_1.TabStop = false;
            // 
            // grp_P1_Match4
            // 
            this.grp_P1_Match4.Controls.Add(this.pic_P1_Match4_3);
            this.grp_P1_Match4.Controls.Add(this.pic_P1_Match4_2);
            this.grp_P1_Match4.Controls.Add(this.pic_P1_Match4_1);
            this.grp_P1_Match4.Location = new System.Drawing.Point(306, 141);
            this.grp_P1_Match4.Name = "grp_P1_Match4";
            this.grp_P1_Match4.Size = new System.Drawing.Size(288, 114);
            this.grp_P1_Match4.TabIndex = 9;
            this.grp_P1_Match4.TabStop = false;
            this.grp_P1_Match4.Text = "Match #4";
            this.grp_P1_Match4.Visible = false;
            // 
            // pic_P1_Match4_3
            // 
            this.pic_P1_Match4_3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pic_P1_Match4_3.Image = ((System.Drawing.Image)(resources.GetObject("pic_P1_Match4_3.Image")));
            this.pic_P1_Match4_3.Location = new System.Drawing.Point(195, 18);
            this.pic_P1_Match4_3.Name = "pic_P1_Match4_3";
            this.pic_P1_Match4_3.Size = new System.Drawing.Size(87, 87);
            this.pic_P1_Match4_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_P1_Match4_3.TabIndex = 3;
            this.pic_P1_Match4_3.TabStop = false;
            // 
            // pic_P1_Match4_2
            // 
            this.pic_P1_Match4_2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pic_P1_Match4_2.Image = ((System.Drawing.Image)(resources.GetObject("pic_P1_Match4_2.Image")));
            this.pic_P1_Match4_2.Location = new System.Drawing.Point(102, 18);
            this.pic_P1_Match4_2.Name = "pic_P1_Match4_2";
            this.pic_P1_Match4_2.Size = new System.Drawing.Size(87, 87);
            this.pic_P1_Match4_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_P1_Match4_2.TabIndex = 2;
            this.pic_P1_Match4_2.TabStop = false;
            // 
            // pic_P1_Match4_1
            // 
            this.pic_P1_Match4_1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pic_P1_Match4_1.Image = ((System.Drawing.Image)(resources.GetObject("pic_P1_Match4_1.Image")));
            this.pic_P1_Match4_1.Location = new System.Drawing.Point(9, 18);
            this.pic_P1_Match4_1.Name = "pic_P1_Match4_1";
            this.pic_P1_Match4_1.Size = new System.Drawing.Size(87, 87);
            this.pic_P1_Match4_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_P1_Match4_1.TabIndex = 1;
            this.pic_P1_Match4_1.TabStop = false;
            // 
            // grp_P1_Match3
            // 
            this.grp_P1_Match3.Controls.Add(this.pic_P1_Match3_3);
            this.grp_P1_Match3.Controls.Add(this.pic_P1_Match3_2);
            this.grp_P1_Match3.Controls.Add(this.pic_P1_Match3_1);
            this.grp_P1_Match3.Location = new System.Drawing.Point(6, 141);
            this.grp_P1_Match3.Name = "grp_P1_Match3";
            this.grp_P1_Match3.Size = new System.Drawing.Size(288, 114);
            this.grp_P1_Match3.TabIndex = 8;
            this.grp_P1_Match3.TabStop = false;
            this.grp_P1_Match3.Text = "Match #3";
            this.grp_P1_Match3.Visible = false;
            // 
            // pic_P1_Match3_3
            // 
            this.pic_P1_Match3_3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pic_P1_Match3_3.Image = ((System.Drawing.Image)(resources.GetObject("pic_P1_Match3_3.Image")));
            this.pic_P1_Match3_3.Location = new System.Drawing.Point(195, 18);
            this.pic_P1_Match3_3.Name = "pic_P1_Match3_3";
            this.pic_P1_Match3_3.Size = new System.Drawing.Size(87, 87);
            this.pic_P1_Match3_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_P1_Match3_3.TabIndex = 3;
            this.pic_P1_Match3_3.TabStop = false;
            // 
            // pic_P1_Match3_2
            // 
            this.pic_P1_Match3_2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pic_P1_Match3_2.Image = ((System.Drawing.Image)(resources.GetObject("pic_P1_Match3_2.Image")));
            this.pic_P1_Match3_2.Location = new System.Drawing.Point(102, 18);
            this.pic_P1_Match3_2.Name = "pic_P1_Match3_2";
            this.pic_P1_Match3_2.Size = new System.Drawing.Size(87, 87);
            this.pic_P1_Match3_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_P1_Match3_2.TabIndex = 2;
            this.pic_P1_Match3_2.TabStop = false;
            // 
            // pic_P1_Match3_1
            // 
            this.pic_P1_Match3_1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pic_P1_Match3_1.Image = ((System.Drawing.Image)(resources.GetObject("pic_P1_Match3_1.Image")));
            this.pic_P1_Match3_1.Location = new System.Drawing.Point(9, 18);
            this.pic_P1_Match3_1.Name = "pic_P1_Match3_1";
            this.pic_P1_Match3_1.Size = new System.Drawing.Size(87, 87);
            this.pic_P1_Match3_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_P1_Match3_1.TabIndex = 1;
            this.pic_P1_Match3_1.TabStop = false;
            // 
            // grp_P1_Match2
            // 
            this.grp_P1_Match2.Controls.Add(this.pic_P1_Match2_3);
            this.grp_P1_Match2.Controls.Add(this.pic_P1_Match2_2);
            this.grp_P1_Match2.Controls.Add(this.pic_P1_Match2_1);
            this.grp_P1_Match2.Location = new System.Drawing.Point(306, 21);
            this.grp_P1_Match2.Name = "grp_P1_Match2";
            this.grp_P1_Match2.Size = new System.Drawing.Size(288, 114);
            this.grp_P1_Match2.TabIndex = 8;
            this.grp_P1_Match2.TabStop = false;
            this.grp_P1_Match2.Text = "Match #2";
            this.grp_P1_Match2.Visible = false;
            // 
            // pic_P1_Match2_3
            // 
            this.pic_P1_Match2_3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pic_P1_Match2_3.Image = ((System.Drawing.Image)(resources.GetObject("pic_P1_Match2_3.Image")));
            this.pic_P1_Match2_3.Location = new System.Drawing.Point(195, 18);
            this.pic_P1_Match2_3.Name = "pic_P1_Match2_3";
            this.pic_P1_Match2_3.Size = new System.Drawing.Size(87, 87);
            this.pic_P1_Match2_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_P1_Match2_3.TabIndex = 3;
            this.pic_P1_Match2_3.TabStop = false;
            // 
            // pic_P1_Match2_2
            // 
            this.pic_P1_Match2_2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pic_P1_Match2_2.Image = ((System.Drawing.Image)(resources.GetObject("pic_P1_Match2_2.Image")));
            this.pic_P1_Match2_2.Location = new System.Drawing.Point(102, 18);
            this.pic_P1_Match2_2.Name = "pic_P1_Match2_2";
            this.pic_P1_Match2_2.Size = new System.Drawing.Size(87, 87);
            this.pic_P1_Match2_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_P1_Match2_2.TabIndex = 2;
            this.pic_P1_Match2_2.TabStop = false;
            // 
            // pic_P1_Match2_1
            // 
            this.pic_P1_Match2_1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pic_P1_Match2_1.Image = ((System.Drawing.Image)(resources.GetObject("pic_P1_Match2_1.Image")));
            this.pic_P1_Match2_1.Location = new System.Drawing.Point(9, 18);
            this.pic_P1_Match2_1.Name = "pic_P1_Match2_1";
            this.pic_P1_Match2_1.Size = new System.Drawing.Size(87, 87);
            this.pic_P1_Match2_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_P1_Match2_1.TabIndex = 1;
            this.pic_P1_Match2_1.TabStop = false;
            // 
            // grp_P1_Match1
            // 
            this.grp_P1_Match1.Controls.Add(this.pic_P1_Match1_3);
            this.grp_P1_Match1.Controls.Add(this.pic_P1_Match1_2);
            this.grp_P1_Match1.Controls.Add(this.pic_P1_Match1_1);
            this.grp_P1_Match1.Location = new System.Drawing.Point(6, 21);
            this.grp_P1_Match1.Name = "grp_P1_Match1";
            this.grp_P1_Match1.Size = new System.Drawing.Size(288, 114);
            this.grp_P1_Match1.TabIndex = 7;
            this.grp_P1_Match1.TabStop = false;
            this.grp_P1_Match1.Text = "Match #1";
            this.grp_P1_Match1.Visible = false;
            // 
            // pic_P1_Match1_3
            // 
            this.pic_P1_Match1_3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pic_P1_Match1_3.Image = ((System.Drawing.Image)(resources.GetObject("pic_P1_Match1_3.Image")));
            this.pic_P1_Match1_3.Location = new System.Drawing.Point(195, 18);
            this.pic_P1_Match1_3.Name = "pic_P1_Match1_3";
            this.pic_P1_Match1_3.Size = new System.Drawing.Size(87, 87);
            this.pic_P1_Match1_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_P1_Match1_3.TabIndex = 3;
            this.pic_P1_Match1_3.TabStop = false;
            // 
            // pic_P1_Match1_2
            // 
            this.pic_P1_Match1_2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pic_P1_Match1_2.Image = ((System.Drawing.Image)(resources.GetObject("pic_P1_Match1_2.Image")));
            this.pic_P1_Match1_2.Location = new System.Drawing.Point(102, 18);
            this.pic_P1_Match1_2.Name = "pic_P1_Match1_2";
            this.pic_P1_Match1_2.Size = new System.Drawing.Size(87, 87);
            this.pic_P1_Match1_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_P1_Match1_2.TabIndex = 2;
            this.pic_P1_Match1_2.TabStop = false;
            // 
            // pic_P1_Match1_1
            // 
            this.pic_P1_Match1_1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pic_P1_Match1_1.Image = ((System.Drawing.Image)(resources.GetObject("pic_P1_Match1_1.Image")));
            this.pic_P1_Match1_1.Location = new System.Drawing.Point(9, 18);
            this.pic_P1_Match1_1.Name = "pic_P1_Match1_1";
            this.pic_P1_Match1_1.Size = new System.Drawing.Size(87, 87);
            this.pic_P1_Match1_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_P1_Match1_1.TabIndex = 1;
            this.pic_P1_Match1_1.TabStop = false;
            // 
            // grp_Player
            // 
            this.grp_Player.Controls.Add(this.chk_Card7);
            this.grp_Player.Controls.Add(this.chk_Card6);
            this.grp_Player.Controls.Add(this.chk_Card5);
            this.grp_Player.Controls.Add(this.chk_Card4);
            this.grp_Player.Controls.Add(this.chk_Card3);
            this.grp_Player.Controls.Add(this.chk_Card2);
            this.grp_Player.Controls.Add(this.chk_Card1);
            this.grp_Player.Controls.Add(this.pic_Card7);
            this.grp_Player.Controls.Add(this.pic_Card6);
            this.grp_Player.Controls.Add(this.pic_Card5);
            this.grp_Player.Controls.Add(this.pic_Card4);
            this.grp_Player.Controls.Add(this.pic_Card3);
            this.grp_Player.Controls.Add(this.pic_Card2);
            this.grp_Player.Controls.Add(this.pic_Card1);
            this.grp_Player.Location = new System.Drawing.Point(12, 401);
            this.grp_Player.Name = "grp_Player";
            this.grp_Player.Size = new System.Drawing.Size(680, 136);
            this.grp_Player.TabIndex = 0;
            this.grp_Player.TabStop = false;
            this.grp_Player.Text = "Your cards";
            // 
            // chk_Card7
            // 
            this.chk_Card7.AutoSize = true;
            this.chk_Card7.BackColor = System.Drawing.Color.Transparent;
            this.chk_Card7.Location = new System.Drawing.Point(651, 30);
            this.chk_Card7.Name = "chk_Card7";
            this.chk_Card7.Size = new System.Drawing.Size(15, 14);
            this.chk_Card7.TabIndex = 6;
            this.chk_Card7.UseVisualStyleBackColor = false;
            // 
            // chk_Card6
            // 
            this.chk_Card6.AutoSize = true;
            this.chk_Card6.BackColor = System.Drawing.Color.Transparent;
            this.chk_Card6.Location = new System.Drawing.Point(558, 30);
            this.chk_Card6.Name = "chk_Card6";
            this.chk_Card6.Size = new System.Drawing.Size(15, 14);
            this.chk_Card6.TabIndex = 5;
            this.chk_Card6.UseVisualStyleBackColor = false;
            // 
            // chk_Card5
            // 
            this.chk_Card5.AutoSize = true;
            this.chk_Card5.BackColor = System.Drawing.Color.Transparent;
            this.chk_Card5.Location = new System.Drawing.Point(465, 30);
            this.chk_Card5.Name = "chk_Card5";
            this.chk_Card5.Size = new System.Drawing.Size(15, 14);
            this.chk_Card5.TabIndex = 4;
            this.chk_Card5.UseVisualStyleBackColor = false;
            // 
            // chk_Card4
            // 
            this.chk_Card4.AutoSize = true;
            this.chk_Card4.BackColor = System.Drawing.Color.Transparent;
            this.chk_Card4.Location = new System.Drawing.Point(372, 30);
            this.chk_Card4.Name = "chk_Card4";
            this.chk_Card4.Size = new System.Drawing.Size(15, 14);
            this.chk_Card4.TabIndex = 3;
            this.chk_Card4.UseVisualStyleBackColor = false;
            // 
            // chk_Card3
            // 
            this.chk_Card3.AutoSize = true;
            this.chk_Card3.BackColor = System.Drawing.Color.Transparent;
            this.chk_Card3.Location = new System.Drawing.Point(279, 30);
            this.chk_Card3.Name = "chk_Card3";
            this.chk_Card3.Size = new System.Drawing.Size(15, 14);
            this.chk_Card3.TabIndex = 2;
            this.chk_Card3.UseVisualStyleBackColor = false;
            // 
            // chk_Card2
            // 
            this.chk_Card2.AutoSize = true;
            this.chk_Card2.BackColor = System.Drawing.Color.Transparent;
            this.chk_Card2.Location = new System.Drawing.Point(186, 30);
            this.chk_Card2.Name = "chk_Card2";
            this.chk_Card2.Size = new System.Drawing.Size(15, 14);
            this.chk_Card2.TabIndex = 1;
            this.chk_Card2.UseVisualStyleBackColor = false;
            // 
            // chk_Card1
            // 
            this.chk_Card1.AutoSize = true;
            this.chk_Card1.BackColor = System.Drawing.Color.Transparent;
            this.chk_Card1.Location = new System.Drawing.Point(93, 30);
            this.chk_Card1.Name = "chk_Card1";
            this.chk_Card1.Size = new System.Drawing.Size(15, 14);
            this.chk_Card1.TabIndex = 0;
            this.chk_Card1.UseVisualStyleBackColor = false;
            // 
            // pic_Card7
            // 
            this.pic_Card7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pic_Card7.Image = ((System.Drawing.Image)(resources.GetObject("pic_Card7.Image")));
            this.pic_Card7.Location = new System.Drawing.Point(579, 30);
            this.pic_Card7.Name = "pic_Card7";
            this.pic_Card7.Size = new System.Drawing.Size(87, 87);
            this.pic_Card7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_Card7.TabIndex = 6;
            this.pic_Card7.TabStop = false;
            this.pic_Card7.Click += new System.EventHandler(this.pic_Card7_Click);
            // 
            // pic_Card6
            // 
            this.pic_Card6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pic_Card6.Image = ((System.Drawing.Image)(resources.GetObject("pic_Card6.Image")));
            this.pic_Card6.Location = new System.Drawing.Point(486, 30);
            this.pic_Card6.Name = "pic_Card6";
            this.pic_Card6.Size = new System.Drawing.Size(87, 87);
            this.pic_Card6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_Card6.TabIndex = 5;
            this.pic_Card6.TabStop = false;
            this.pic_Card6.Click += new System.EventHandler(this.pic_Card6_Click);
            // 
            // pic_Card5
            // 
            this.pic_Card5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pic_Card5.Image = ((System.Drawing.Image)(resources.GetObject("pic_Card5.Image")));
            this.pic_Card5.Location = new System.Drawing.Point(393, 30);
            this.pic_Card5.Name = "pic_Card5";
            this.pic_Card5.Size = new System.Drawing.Size(87, 87);
            this.pic_Card5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_Card5.TabIndex = 4;
            this.pic_Card5.TabStop = false;
            this.pic_Card5.Click += new System.EventHandler(this.pic_Card5_Click);
            // 
            // pic_Card4
            // 
            this.pic_Card4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pic_Card4.Image = ((System.Drawing.Image)(resources.GetObject("pic_Card4.Image")));
            this.pic_Card4.Location = new System.Drawing.Point(300, 30);
            this.pic_Card4.Name = "pic_Card4";
            this.pic_Card4.Size = new System.Drawing.Size(87, 87);
            this.pic_Card4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_Card4.TabIndex = 3;
            this.pic_Card4.TabStop = false;
            this.pic_Card4.Click += new System.EventHandler(this.pic_Card4_Click);
            // 
            // pic_Card3
            // 
            this.pic_Card3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pic_Card3.Image = ((System.Drawing.Image)(resources.GetObject("pic_Card3.Image")));
            this.pic_Card3.Location = new System.Drawing.Point(207, 30);
            this.pic_Card3.Name = "pic_Card3";
            this.pic_Card3.Size = new System.Drawing.Size(87, 87);
            this.pic_Card3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_Card3.TabIndex = 2;
            this.pic_Card3.TabStop = false;
            this.pic_Card3.Click += new System.EventHandler(this.pic_Card3_Click);
            // 
            // pic_Card2
            // 
            this.pic_Card2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pic_Card2.Image = ((System.Drawing.Image)(resources.GetObject("pic_Card2.Image")));
            this.pic_Card2.Location = new System.Drawing.Point(114, 30);
            this.pic_Card2.Name = "pic_Card2";
            this.pic_Card2.Size = new System.Drawing.Size(87, 87);
            this.pic_Card2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_Card2.TabIndex = 1;
            this.pic_Card2.TabStop = false;
            this.pic_Card2.Click += new System.EventHandler(this.pic_Card2_Click);
            // 
            // pic_Card1
            // 
            this.pic_Card1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pic_Card1.Image = ((System.Drawing.Image)(resources.GetObject("pic_Card1.Image")));
            this.pic_Card1.Location = new System.Drawing.Point(21, 30);
            this.pic_Card1.Name = "pic_Card1";
            this.pic_Card1.Size = new System.Drawing.Size(87, 87);
            this.pic_Card1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_Card1.TabIndex = 0;
            this.pic_Card1.TabStop = false;
            this.pic_Card1.Click += new System.EventHandler(this.pic_Card1_Click);
            // 
            // btn_Draw
            // 
            this.btn_Draw.Location = new System.Drawing.Point(727, 419);
            this.btn_Draw.Name = "btn_Draw";
            this.btn_Draw.Size = new System.Drawing.Size(75, 23);
            this.btn_Draw.TabIndex = 1;
            this.btn_Draw.Text = "&Draw";
            this.toolTip1.SetToolTip(this.btn_Draw, "Hope that rng gives you the card you want");
            this.btn_Draw.UseVisualStyleBackColor = true;
            this.btn_Draw.Click += new System.EventHandler(this.btn_Draw_Click);
            // 
            // btn_Discard
            // 
            this.btn_Discard.Location = new System.Drawing.Point(727, 448);
            this.btn_Discard.Name = "btn_Discard";
            this.btn_Discard.Size = new System.Drawing.Size(75, 23);
            this.btn_Discard.TabIndex = 2;
            this.btn_Discard.Text = "Di&scard";
            this.toolTip1.SetToolTip(this.btn_Discard, "Put the selected card back in the deck so you can draw it again.... over and over" +
        "!");
            this.btn_Discard.UseVisualStyleBackColor = true;
            this.btn_Discard.Click += new System.EventHandler(this.btn_Discard_Click);
            // 
            // btn_Match
            // 
            this.btn_Match.Location = new System.Drawing.Point(727, 477);
            this.btn_Match.Name = "btn_Match";
            this.btn_Match.Size = new System.Drawing.Size(75, 23);
            this.btn_Match.TabIndex = 3;
            this.btn_Match.Text = "&Match";
            this.toolTip1.SetToolTip(this.btn_Match, "Test if your program is working. Result: Probably not");
            this.btn_Match.UseVisualStyleBackColor = true;
            this.btn_Match.Click += new System.EventHandler(this.btn_Match_Click);
            // 
            // btn_Next
            // 
            this.btn_Next.Location = new System.Drawing.Point(727, 506);
            this.btn_Next.Name = "btn_Next";
            this.btn_Next.Size = new System.Drawing.Size(75, 23);
            this.btn_Next.TabIndex = 4;
            this.btn_Next.Text = "&Next Turn";
            this.toolTip1.SetToolTip(this.btn_Next, "Pass on the turn to the other player..... Yourself");
            this.btn_Next.UseVisualStyleBackColor = true;
            this.btn_Next.Click += new System.EventHandler(this.btn_Next_Click);
            // 
            // btn_ExitMain
            // 
            this.btn_ExitMain.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btn_ExitMain.Location = new System.Drawing.Point(1147, 506);
            this.btn_ExitMain.Name = "btn_ExitMain";
            this.btn_ExitMain.Size = new System.Drawing.Size(75, 23);
            this.btn_ExitMain.TabIndex = 8;
            this.btn_ExitMain.Text = "E&xit";
            this.toolTip1.SetToolTip(this.btn_ExitMain, "Yep, thats enough for the day");
            this.btn_ExitMain.UseVisualStyleBackColor = true;
            this.btn_ExitMain.Click += new System.EventHandler(this.btn_ExitMain_Click);
            // 
            // btn_Replay
            // 
            this.btn_Replay.Location = new System.Drawing.Point(1147, 459);
            this.btn_Replay.Name = "btn_Replay";
            this.btn_Replay.Size = new System.Drawing.Size(75, 23);
            this.btn_Replay.TabIndex = 7;
            this.btn_Replay.Text = "Re&play";
            this.toolTip1.SetToolTip(this.btn_Replay, "Didn\'t think you\'d even consider pressing this button");
            this.btn_Replay.UseVisualStyleBackColor = true;
            this.btn_Replay.Visible = false;
            this.btn_Replay.Click += new System.EventHandler(this.btn_Replay_Click);
            // 
            // grp_P2_Matches
            // 
            this.grp_P2_Matches.Controls.Add(this.grp_P2_Match6);
            this.grp_P2_Matches.Controls.Add(this.grp_P2_Match5);
            this.grp_P2_Matches.Controls.Add(this.grp_P2_Match4);
            this.grp_P2_Matches.Controls.Add(this.grp_P2_Match3);
            this.grp_P2_Matches.Controls.Add(this.grp_P2_Match2);
            this.grp_P2_Matches.Controls.Add(this.grp_P2_Match1);
            this.grp_P2_Matches.Location = new System.Drawing.Point(620, 12);
            this.grp_P2_Matches.Name = "grp_P2_Matches";
            this.grp_P2_Matches.Size = new System.Drawing.Size(602, 383);
            this.grp_P2_Matches.TabIndex = 10;
            this.grp_P2_Matches.TabStop = false;
            this.grp_P2_Matches.Text = "Player 2\'s Matches";
            // 
            // grp_P2_Match6
            // 
            this.grp_P2_Match6.Controls.Add(this.pic_P2_Match6_3);
            this.grp_P2_Match6.Controls.Add(this.pic_P2_Match6_2);
            this.grp_P2_Match6.Controls.Add(this.pic_P2_Match6_1);
            this.grp_P2_Match6.Location = new System.Drawing.Point(306, 261);
            this.grp_P2_Match6.Name = "grp_P2_Match6";
            this.grp_P2_Match6.Size = new System.Drawing.Size(288, 114);
            this.grp_P2_Match6.TabIndex = 8;
            this.grp_P2_Match6.TabStop = false;
            this.grp_P2_Match6.Text = "Match #6";
            this.grp_P2_Match6.Visible = false;
            // 
            // pic_P2_Match6_3
            // 
            this.pic_P2_Match6_3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pic_P2_Match6_3.Image = ((System.Drawing.Image)(resources.GetObject("pic_P2_Match6_3.Image")));
            this.pic_P2_Match6_3.Location = new System.Drawing.Point(195, 18);
            this.pic_P2_Match6_3.Name = "pic_P2_Match6_3";
            this.pic_P2_Match6_3.Size = new System.Drawing.Size(87, 87);
            this.pic_P2_Match6_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_P2_Match6_3.TabIndex = 3;
            this.pic_P2_Match6_3.TabStop = false;
            // 
            // pic_P2_Match6_2
            // 
            this.pic_P2_Match6_2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pic_P2_Match6_2.Image = ((System.Drawing.Image)(resources.GetObject("pic_P2_Match6_2.Image")));
            this.pic_P2_Match6_2.Location = new System.Drawing.Point(102, 18);
            this.pic_P2_Match6_2.Name = "pic_P2_Match6_2";
            this.pic_P2_Match6_2.Size = new System.Drawing.Size(87, 87);
            this.pic_P2_Match6_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_P2_Match6_2.TabIndex = 2;
            this.pic_P2_Match6_2.TabStop = false;
            // 
            // pic_P2_Match6_1
            // 
            this.pic_P2_Match6_1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pic_P2_Match6_1.Image = ((System.Drawing.Image)(resources.GetObject("pic_P2_Match6_1.Image")));
            this.pic_P2_Match6_1.Location = new System.Drawing.Point(9, 18);
            this.pic_P2_Match6_1.Name = "pic_P2_Match6_1";
            this.pic_P2_Match6_1.Size = new System.Drawing.Size(87, 87);
            this.pic_P2_Match6_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_P2_Match6_1.TabIndex = 1;
            this.pic_P2_Match6_1.TabStop = false;
            // 
            // grp_P2_Match5
            // 
            this.grp_P2_Match5.Controls.Add(this.pic_P2_Match5_3);
            this.grp_P2_Match5.Controls.Add(this.pic_P2_Match5_2);
            this.grp_P2_Match5.Controls.Add(this.pic_P2_Match5_1);
            this.grp_P2_Match5.Location = new System.Drawing.Point(6, 261);
            this.grp_P2_Match5.Name = "grp_P2_Match5";
            this.grp_P2_Match5.Size = new System.Drawing.Size(288, 114);
            this.grp_P2_Match5.TabIndex = 8;
            this.grp_P2_Match5.TabStop = false;
            this.grp_P2_Match5.Text = "Match #5";
            this.grp_P2_Match5.Visible = false;
            // 
            // pic_P2_Match5_3
            // 
            this.pic_P2_Match5_3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pic_P2_Match5_3.Image = ((System.Drawing.Image)(resources.GetObject("pic_P2_Match5_3.Image")));
            this.pic_P2_Match5_3.Location = new System.Drawing.Point(195, 18);
            this.pic_P2_Match5_3.Name = "pic_P2_Match5_3";
            this.pic_P2_Match5_3.Size = new System.Drawing.Size(87, 87);
            this.pic_P2_Match5_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_P2_Match5_3.TabIndex = 3;
            this.pic_P2_Match5_3.TabStop = false;
            // 
            // pic_P2_Match5_2
            // 
            this.pic_P2_Match5_2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pic_P2_Match5_2.Image = ((System.Drawing.Image)(resources.GetObject("pic_P2_Match5_2.Image")));
            this.pic_P2_Match5_2.Location = new System.Drawing.Point(102, 18);
            this.pic_P2_Match5_2.Name = "pic_P2_Match5_2";
            this.pic_P2_Match5_2.Size = new System.Drawing.Size(87, 87);
            this.pic_P2_Match5_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_P2_Match5_2.TabIndex = 2;
            this.pic_P2_Match5_2.TabStop = false;
            // 
            // pic_P2_Match5_1
            // 
            this.pic_P2_Match5_1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pic_P2_Match5_1.Image = ((System.Drawing.Image)(resources.GetObject("pic_P2_Match5_1.Image")));
            this.pic_P2_Match5_1.Location = new System.Drawing.Point(9, 18);
            this.pic_P2_Match5_1.Name = "pic_P2_Match5_1";
            this.pic_P2_Match5_1.Size = new System.Drawing.Size(87, 87);
            this.pic_P2_Match5_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_P2_Match5_1.TabIndex = 1;
            this.pic_P2_Match5_1.TabStop = false;
            // 
            // grp_P2_Match4
            // 
            this.grp_P2_Match4.Controls.Add(this.pic_P2_Match4_3);
            this.grp_P2_Match4.Controls.Add(this.pic_P2_Match4_2);
            this.grp_P2_Match4.Controls.Add(this.pic_P2_Match4_1);
            this.grp_P2_Match4.Location = new System.Drawing.Point(306, 141);
            this.grp_P2_Match4.Name = "grp_P2_Match4";
            this.grp_P2_Match4.Size = new System.Drawing.Size(288, 114);
            this.grp_P2_Match4.TabIndex = 9;
            this.grp_P2_Match4.TabStop = false;
            this.grp_P2_Match4.Text = "Match #4";
            this.grp_P2_Match4.Visible = false;
            // 
            // pic_P2_Match4_3
            // 
            this.pic_P2_Match4_3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pic_P2_Match4_3.Image = ((System.Drawing.Image)(resources.GetObject("pic_P2_Match4_3.Image")));
            this.pic_P2_Match4_3.Location = new System.Drawing.Point(195, 18);
            this.pic_P2_Match4_3.Name = "pic_P2_Match4_3";
            this.pic_P2_Match4_3.Size = new System.Drawing.Size(87, 87);
            this.pic_P2_Match4_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_P2_Match4_3.TabIndex = 3;
            this.pic_P2_Match4_3.TabStop = false;
            // 
            // pic_P2_Match4_2
            // 
            this.pic_P2_Match4_2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pic_P2_Match4_2.Image = ((System.Drawing.Image)(resources.GetObject("pic_P2_Match4_2.Image")));
            this.pic_P2_Match4_2.Location = new System.Drawing.Point(102, 18);
            this.pic_P2_Match4_2.Name = "pic_P2_Match4_2";
            this.pic_P2_Match4_2.Size = new System.Drawing.Size(87, 87);
            this.pic_P2_Match4_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_P2_Match4_2.TabIndex = 2;
            this.pic_P2_Match4_2.TabStop = false;
            // 
            // pic_P2_Match4_1
            // 
            this.pic_P2_Match4_1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pic_P2_Match4_1.Image = ((System.Drawing.Image)(resources.GetObject("pic_P2_Match4_1.Image")));
            this.pic_P2_Match4_1.Location = new System.Drawing.Point(9, 18);
            this.pic_P2_Match4_1.Name = "pic_P2_Match4_1";
            this.pic_P2_Match4_1.Size = new System.Drawing.Size(87, 87);
            this.pic_P2_Match4_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_P2_Match4_1.TabIndex = 1;
            this.pic_P2_Match4_1.TabStop = false;
            // 
            // grp_P2_Match3
            // 
            this.grp_P2_Match3.Controls.Add(this.pic_P2_Match3_3);
            this.grp_P2_Match3.Controls.Add(this.pic_P2_Match3_2);
            this.grp_P2_Match3.Controls.Add(this.pic_P2_Match3_1);
            this.grp_P2_Match3.Location = new System.Drawing.Point(6, 141);
            this.grp_P2_Match3.Name = "grp_P2_Match3";
            this.grp_P2_Match3.Size = new System.Drawing.Size(288, 114);
            this.grp_P2_Match3.TabIndex = 8;
            this.grp_P2_Match3.TabStop = false;
            this.grp_P2_Match3.Text = "Match #3";
            this.grp_P2_Match3.Visible = false;
            // 
            // pic_P2_Match3_3
            // 
            this.pic_P2_Match3_3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pic_P2_Match3_3.Image = ((System.Drawing.Image)(resources.GetObject("pic_P2_Match3_3.Image")));
            this.pic_P2_Match3_3.Location = new System.Drawing.Point(195, 18);
            this.pic_P2_Match3_3.Name = "pic_P2_Match3_3";
            this.pic_P2_Match3_3.Size = new System.Drawing.Size(87, 87);
            this.pic_P2_Match3_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_P2_Match3_3.TabIndex = 3;
            this.pic_P2_Match3_3.TabStop = false;
            // 
            // pic_P2_Match3_2
            // 
            this.pic_P2_Match3_2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pic_P2_Match3_2.Image = ((System.Drawing.Image)(resources.GetObject("pic_P2_Match3_2.Image")));
            this.pic_P2_Match3_2.Location = new System.Drawing.Point(102, 18);
            this.pic_P2_Match3_2.Name = "pic_P2_Match3_2";
            this.pic_P2_Match3_2.Size = new System.Drawing.Size(87, 87);
            this.pic_P2_Match3_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_P2_Match3_2.TabIndex = 2;
            this.pic_P2_Match3_2.TabStop = false;
            // 
            // pic_P2_Match3_1
            // 
            this.pic_P2_Match3_1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pic_P2_Match3_1.Image = ((System.Drawing.Image)(resources.GetObject("pic_P2_Match3_1.Image")));
            this.pic_P2_Match3_1.Location = new System.Drawing.Point(9, 18);
            this.pic_P2_Match3_1.Name = "pic_P2_Match3_1";
            this.pic_P2_Match3_1.Size = new System.Drawing.Size(87, 87);
            this.pic_P2_Match3_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_P2_Match3_1.TabIndex = 1;
            this.pic_P2_Match3_1.TabStop = false;
            // 
            // grp_P2_Match2
            // 
            this.grp_P2_Match2.Controls.Add(this.pic_P2_Match2_3);
            this.grp_P2_Match2.Controls.Add(this.pic_P2_Match2_2);
            this.grp_P2_Match2.Controls.Add(this.pic_P2_Match2_1);
            this.grp_P2_Match2.Location = new System.Drawing.Point(306, 21);
            this.grp_P2_Match2.Name = "grp_P2_Match2";
            this.grp_P2_Match2.Size = new System.Drawing.Size(288, 114);
            this.grp_P2_Match2.TabIndex = 8;
            this.grp_P2_Match2.TabStop = false;
            this.grp_P2_Match2.Text = "Match #2";
            this.grp_P2_Match2.Visible = false;
            // 
            // pic_P2_Match2_3
            // 
            this.pic_P2_Match2_3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pic_P2_Match2_3.Image = ((System.Drawing.Image)(resources.GetObject("pic_P2_Match2_3.Image")));
            this.pic_P2_Match2_3.Location = new System.Drawing.Point(195, 18);
            this.pic_P2_Match2_3.Name = "pic_P2_Match2_3";
            this.pic_P2_Match2_3.Size = new System.Drawing.Size(87, 87);
            this.pic_P2_Match2_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_P2_Match2_3.TabIndex = 3;
            this.pic_P2_Match2_3.TabStop = false;
            // 
            // pic_P2_Match2_2
            // 
            this.pic_P2_Match2_2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pic_P2_Match2_2.Image = ((System.Drawing.Image)(resources.GetObject("pic_P2_Match2_2.Image")));
            this.pic_P2_Match2_2.Location = new System.Drawing.Point(102, 18);
            this.pic_P2_Match2_2.Name = "pic_P2_Match2_2";
            this.pic_P2_Match2_2.Size = new System.Drawing.Size(87, 87);
            this.pic_P2_Match2_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_P2_Match2_2.TabIndex = 2;
            this.pic_P2_Match2_2.TabStop = false;
            // 
            // pic_P2_Match2_1
            // 
            this.pic_P2_Match2_1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pic_P2_Match2_1.Image = ((System.Drawing.Image)(resources.GetObject("pic_P2_Match2_1.Image")));
            this.pic_P2_Match2_1.Location = new System.Drawing.Point(9, 18);
            this.pic_P2_Match2_1.Name = "pic_P2_Match2_1";
            this.pic_P2_Match2_1.Size = new System.Drawing.Size(87, 87);
            this.pic_P2_Match2_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_P2_Match2_1.TabIndex = 1;
            this.pic_P2_Match2_1.TabStop = false;
            // 
            // grp_P2_Match1
            // 
            this.grp_P2_Match1.Controls.Add(this.pic_P2_Match1_3);
            this.grp_P2_Match1.Controls.Add(this.pic_P2_Match1_2);
            this.grp_P2_Match1.Controls.Add(this.pic_P2_Match1_1);
            this.grp_P2_Match1.Location = new System.Drawing.Point(6, 21);
            this.grp_P2_Match1.Name = "grp_P2_Match1";
            this.grp_P2_Match1.Size = new System.Drawing.Size(288, 114);
            this.grp_P2_Match1.TabIndex = 7;
            this.grp_P2_Match1.TabStop = false;
            this.grp_P2_Match1.Text = "Match #1";
            this.grp_P2_Match1.Visible = false;
            // 
            // pic_P2_Match1_3
            // 
            this.pic_P2_Match1_3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pic_P2_Match1_3.Image = ((System.Drawing.Image)(resources.GetObject("pic_P2_Match1_3.Image")));
            this.pic_P2_Match1_3.Location = new System.Drawing.Point(195, 18);
            this.pic_P2_Match1_3.Name = "pic_P2_Match1_3";
            this.pic_P2_Match1_3.Size = new System.Drawing.Size(87, 87);
            this.pic_P2_Match1_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_P2_Match1_3.TabIndex = 3;
            this.pic_P2_Match1_3.TabStop = false;
            // 
            // pic_P2_Match1_2
            // 
            this.pic_P2_Match1_2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pic_P2_Match1_2.Image = ((System.Drawing.Image)(resources.GetObject("pic_P2_Match1_2.Image")));
            this.pic_P2_Match1_2.Location = new System.Drawing.Point(102, 18);
            this.pic_P2_Match1_2.Name = "pic_P2_Match1_2";
            this.pic_P2_Match1_2.Size = new System.Drawing.Size(87, 87);
            this.pic_P2_Match1_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_P2_Match1_2.TabIndex = 2;
            this.pic_P2_Match1_2.TabStop = false;
            // 
            // pic_P2_Match1_1
            // 
            this.pic_P2_Match1_1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pic_P2_Match1_1.Image = ((System.Drawing.Image)(resources.GetObject("pic_P2_Match1_1.Image")));
            this.pic_P2_Match1_1.Location = new System.Drawing.Point(9, 18);
            this.pic_P2_Match1_1.Name = "pic_P2_Match1_1";
            this.pic_P2_Match1_1.Size = new System.Drawing.Size(87, 87);
            this.pic_P2_Match1_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_P2_Match1_1.TabIndex = 1;
            this.pic_P2_Match1_1.TabStop = false;
            // 
            // pic_Discard
            // 
            this.pic_Discard.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pic_Discard.Image = ((System.Drawing.Image)(resources.GetObject("pic_Discard.Image")));
            this.pic_Discard.Location = new System.Drawing.Point(15, 30);
            this.pic_Discard.Name = "pic_Discard";
            this.pic_Discard.Size = new System.Drawing.Size(87, 87);
            this.pic_Discard.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_Discard.TabIndex = 11;
            this.pic_Discard.TabStop = false;
            // 
            // grp_Discard
            // 
            this.grp_Discard.Controls.Add(this.btn_Take);
            this.grp_Discard.Controls.Add(this.pic_Discard);
            this.grp_Discard.Location = new System.Drawing.Point(874, 401);
            this.grp_Discard.Name = "grp_Discard";
            this.grp_Discard.Size = new System.Drawing.Size(200, 136);
            this.grp_Discard.TabIndex = 5;
            this.grp_Discard.TabStop = false;
            this.grp_Discard.Text = "Last Discard";
            this.grp_Discard.Visible = false;
            // 
            // btn_Take
            // 
            this.btn_Take.Location = new System.Drawing.Point(113, 58);
            this.btn_Take.Name = "btn_Take";
            this.btn_Take.Size = new System.Drawing.Size(75, 23);
            this.btn_Take.TabIndex = 0;
            this.btn_Take.Text = "&Take";
            this.toolTip1.SetToolTip(this.btn_Take, "One man\'s trash is another man\'s treasure");
            this.btn_Take.UseVisualStyleBackColor = true;
            this.btn_Take.Click += new System.EventHandler(this.btn_Take_Click);
            // 
            // frm_Main
            // 
            this.AcceptButton = this.btn_Draw;
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Aqua;
            this.CancelButton = this.btn_ExitMain;
            this.ClientSize = new System.Drawing.Size(1234, 546);
            this.Controls.Add(this.grp_Discard);
            this.Controls.Add(this.grp_P2_Matches);
            this.Controls.Add(this.btn_Replay);
            this.Controls.Add(this.btn_ExitMain);
            this.Controls.Add(this.btn_Next);
            this.Controls.Add(this.btn_Match);
            this.Controls.Add(this.btn_Discard);
            this.Controls.Add(this.btn_Draw);
            this.Controls.Add(this.grp_Player);
            this.Controls.Add(this.grp_P1_Matches);
            this.Controls.Add(this.btn_Rules);
            this.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "frm_Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Barry Norton Final Project Card Game";
            this.grp_P1_Matches.ResumeLayout(false);
            this.grp_P1_Match6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pic_P1_Match6_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P1_Match6_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P1_Match6_1)).EndInit();
            this.grp_P1_Match5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pic_P1_Match5_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P1_Match5_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P1_Match5_1)).EndInit();
            this.grp_P1_Match4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pic_P1_Match4_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P1_Match4_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P1_Match4_1)).EndInit();
            this.grp_P1_Match3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pic_P1_Match3_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P1_Match3_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P1_Match3_1)).EndInit();
            this.grp_P1_Match2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pic_P1_Match2_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P1_Match2_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P1_Match2_1)).EndInit();
            this.grp_P1_Match1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pic_P1_Match1_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P1_Match1_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P1_Match1_1)).EndInit();
            this.grp_Player.ResumeLayout(false);
            this.grp_Player.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_Card7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_Card6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_Card5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_Card4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_Card3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_Card2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_Card1)).EndInit();
            this.grp_P2_Matches.ResumeLayout(false);
            this.grp_P2_Match6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pic_P2_Match6_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P2_Match6_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P2_Match6_1)).EndInit();
            this.grp_P2_Match5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pic_P2_Match5_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P2_Match5_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P2_Match5_1)).EndInit();
            this.grp_P2_Match4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pic_P2_Match4_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P2_Match4_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P2_Match4_1)).EndInit();
            this.grp_P2_Match3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pic_P2_Match3_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P2_Match3_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P2_Match3_1)).EndInit();
            this.grp_P2_Match2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pic_P2_Match2_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P2_Match2_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P2_Match2_1)).EndInit();
            this.grp_P2_Match1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pic_P2_Match1_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P2_Match1_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_P2_Match1_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_Discard)).EndInit();
            this.grp_Discard.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_Rules;
        private System.Windows.Forms.GroupBox grp_P1_Matches;
        private System.Windows.Forms.GroupBox grp_Player;
        private System.Windows.Forms.Button btn_Draw;
        private System.Windows.Forms.Button btn_Discard;
        private System.Windows.Forms.Button btn_Match;
        private System.Windows.Forms.Button btn_Next;
        private System.Windows.Forms.PictureBox pic_Card7;
        private System.Windows.Forms.PictureBox pic_Card6;
        private System.Windows.Forms.PictureBox pic_Card5;
        private System.Windows.Forms.PictureBox pic_Card4;
        private System.Windows.Forms.PictureBox pic_Card3;
        private System.Windows.Forms.PictureBox pic_Card2;
        private System.Windows.Forms.PictureBox pic_Card1;
        private System.Windows.Forms.CheckBox chk_Card1;
        private System.Windows.Forms.CheckBox chk_Card2;
        private System.Windows.Forms.CheckBox chk_Card7;
        private System.Windows.Forms.CheckBox chk_Card6;
        private System.Windows.Forms.CheckBox chk_Card5;
        private System.Windows.Forms.CheckBox chk_Card4;
        private System.Windows.Forms.CheckBox chk_Card3;
        private System.Windows.Forms.GroupBox grp_P1_Match6;
        private System.Windows.Forms.PictureBox pic_P1_Match6_3;
        private System.Windows.Forms.PictureBox pic_P1_Match6_2;
        private System.Windows.Forms.PictureBox pic_P1_Match6_1;
        private System.Windows.Forms.GroupBox grp_P1_Match5;
        private System.Windows.Forms.PictureBox pic_P1_Match5_3;
        private System.Windows.Forms.PictureBox pic_P1_Match5_2;
        private System.Windows.Forms.PictureBox pic_P1_Match5_1;
        private System.Windows.Forms.GroupBox grp_P1_Match4;
        private System.Windows.Forms.PictureBox pic_P1_Match4_3;
        private System.Windows.Forms.PictureBox pic_P1_Match4_2;
        private System.Windows.Forms.PictureBox pic_P1_Match4_1;
        private System.Windows.Forms.GroupBox grp_P1_Match3;
        private System.Windows.Forms.PictureBox pic_P1_Match3_3;
        private System.Windows.Forms.PictureBox pic_P1_Match3_2;
        private System.Windows.Forms.PictureBox pic_P1_Match3_1;
        private System.Windows.Forms.GroupBox grp_P1_Match2;
        private System.Windows.Forms.PictureBox pic_P1_Match2_3;
        private System.Windows.Forms.PictureBox pic_P1_Match2_2;
        private System.Windows.Forms.PictureBox pic_P1_Match2_1;
        private System.Windows.Forms.GroupBox grp_P1_Match1;
        private System.Windows.Forms.PictureBox pic_P1_Match1_3;
        private System.Windows.Forms.PictureBox pic_P1_Match1_2;
        private System.Windows.Forms.PictureBox pic_P1_Match1_1;
        private System.Windows.Forms.Button btn_ExitMain;
        private System.Windows.Forms.Button btn_Replay;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.GroupBox grp_P2_Matches;
        private System.Windows.Forms.GroupBox grp_P2_Match6;
        private System.Windows.Forms.PictureBox pic_P2_Match6_3;
        private System.Windows.Forms.PictureBox pic_P2_Match6_2;
        private System.Windows.Forms.PictureBox pic_P2_Match6_1;
        private System.Windows.Forms.GroupBox grp_P2_Match5;
        private System.Windows.Forms.PictureBox pic_P2_Match5_3;
        private System.Windows.Forms.PictureBox pic_P2_Match5_2;
        private System.Windows.Forms.PictureBox pic_P2_Match5_1;
        private System.Windows.Forms.GroupBox grp_P2_Match4;
        private System.Windows.Forms.PictureBox pic_P2_Match4_3;
        private System.Windows.Forms.PictureBox pic_P2_Match4_2;
        private System.Windows.Forms.PictureBox pic_P2_Match4_1;
        private System.Windows.Forms.GroupBox grp_P2_Match3;
        private System.Windows.Forms.PictureBox pic_P2_Match3_3;
        private System.Windows.Forms.PictureBox pic_P2_Match3_2;
        private System.Windows.Forms.PictureBox pic_P2_Match3_1;
        private System.Windows.Forms.GroupBox grp_P2_Match2;
        private System.Windows.Forms.PictureBox pic_P2_Match2_3;
        private System.Windows.Forms.PictureBox pic_P2_Match2_2;
        private System.Windows.Forms.PictureBox pic_P2_Match2_1;
        private System.Windows.Forms.GroupBox grp_P2_Match1;
        private System.Windows.Forms.PictureBox pic_P2_Match1_3;
        private System.Windows.Forms.PictureBox pic_P2_Match1_2;
        private System.Windows.Forms.PictureBox pic_P2_Match1_1;
        private System.Windows.Forms.PictureBox pic_Discard;
        private System.Windows.Forms.GroupBox grp_Discard;
        private System.Windows.Forms.Button btn_Take;
    }
}

